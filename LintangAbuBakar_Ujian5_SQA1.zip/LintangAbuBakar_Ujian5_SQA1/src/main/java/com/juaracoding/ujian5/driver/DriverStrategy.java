package com.juaracoding.ujian5.driver;

import org.openqa.selenium.WebDriver;

public interface DriverStrategy {
	
	public WebDriver setStrategy();

}
